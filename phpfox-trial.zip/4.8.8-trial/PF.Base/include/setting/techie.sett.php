<?php
defined('PHPFOX') or exit('NO DICE!');

//Here define settings do not allow Admin edit. If these settings set wrong value, site may break. Only developer can edit here, but check careful before edit.

