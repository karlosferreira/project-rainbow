<?php
/** $Id: md5_sum.xml.php 165 2009-02-05 11:27:19Z phpFox LLC $ **/
defined('PHPFOX') or exit('NO DICE!');
?>