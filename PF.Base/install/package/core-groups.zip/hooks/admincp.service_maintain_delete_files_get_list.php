<?php
$aPluginFiles[] = 'PF.Site/Apps/core-groups/hooks/link.component_service_callback_getactivityfeed__1.php';
$aPluginFiles[] = 'PF.Site/Apps/core-groups/hooks/photo.component_ajax_process_done.php';
