<?php
defined('PHPFOX') or exit('NO DICE!');
?>
<div class="groups-category">
    {template file='core.block.category'}
</div>