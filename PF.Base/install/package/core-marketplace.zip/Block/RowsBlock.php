<?php

namespace Apps\Core_Marketplace\Block;

use Phpfox_Component;

defined('PHPFOX') or exit('NO DICE!');

class RowsBlock extends Phpfox_Component
{

    public function process()
    {

    }
}