<?php

namespace Apps\Core_Music\Service\Playlist;

defined('PHPFOX') or exit('NO DICE!');

use Phpfox_Service;

class Browse extends Phpfox_Service
{
    public function query()
    {

    }

    public function getQueryJoins($bIsCount = false, $bNoQueryFriend = false)
    {

    }
}