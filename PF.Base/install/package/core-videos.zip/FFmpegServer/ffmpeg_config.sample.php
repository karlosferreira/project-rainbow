<?php

defined('PHPFOX') or exit('NO DICE!');

$_aParams = [
    "host"      => "Replace with host of your FFMPEG server",
    "port"      => "Replace with port of your FFMPEG server",
    "username"  => "Replace with username to login to your FFMPEG server",
    "password"  => "Replace with password to login to your FFMPEG server",
    "base_path" => "Replace with path to folder \"/RawVideo\" in your FFMPEG server. Example: /public_html/FFmpeg/RawVideo/",
];