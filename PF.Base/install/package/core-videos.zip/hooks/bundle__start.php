<?php

$aBundleScripts[] = [
    'autoload.css' => 'app_core-videos',
    'autoload.js' => 'app_core-videos',
];