<?php
$aPluginFiles[] = 'PF.Site/Apps/core-videos/hooks/Core_View_Functions_Breadcrumb.php';
$aPluginFiles[] = 'PF.Site/Apps/core-videos/hooks/groups.service_pages_getmenu.php';
$aPluginFiles[] = 'PF.Site/Apps/core-videos/hooks/pages.service_pages_getmenu.php';
$aPluginFiles[] = 'PF.Site/Apps/core-videos/hooks/phpfox_assign_ajax_browsing.php';
$aPluginFiles[] = 'PF.Site/Apps/core-videos/hooks/profile.component_controller_index_process_after_requests.php';
$aPluginFiles[] = 'PF.Site/Apps/core-videos/hooks/profile.service_profile_get_profile_menu.php';
$aPluginFiles[] = 'PF.Site/Apps/core-videos/vendor/zencoder/zencoder-php/LICENSE';
$aPluginFiles[] = 'PF.Site/Apps/core-videos/vendor/zencoder/zencoder-php/README.md';
$aPluginFiles[] = 'PF.Site/Apps/core-videos/views/admincp.html';
$aPluginFiles[] = 'PF.Site/Apps/core-videos/views/admincp_category.html';
$aPluginFiles[] = 'PF.Site/Apps/core-videos/views/categories.html';
$aPluginFiles[] = 'PF.Site/Apps/core-videos/views/delete.html';
$aPluginFiles[] = 'PF.Site/Apps/core-videos/views/feed.html';
$aPluginFiles[] = 'PF.Site/Apps/core-videos/views/index.html';
$aPluginFiles[] = 'PF.Site/Apps/core-videos/views/macro.html';
$aPluginFiles[] = 'PF.Site/Apps/core-videos/views/manage.html';
$aPluginFiles[] = 'PF.Site/Apps/core-videos/views/process.html';
$aPluginFiles[] = 'PF.Site/Apps/core-videos/views/share.html';
$aPluginFiles[] = 'PF.Site/Apps/core-videos/views/view.html';
$aPluginFiles[] = 'PF.Site/Apps/core-videos/vendor/tpyo';

