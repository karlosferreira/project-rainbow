<?php
$this->template()->setPhrase(Phpfox::getService('shoutbox.get')->getPhrases());