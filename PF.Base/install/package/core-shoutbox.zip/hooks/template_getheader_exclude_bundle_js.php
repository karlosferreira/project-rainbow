<?php
$aExcludeBundles[] = 'core-shoutbox/assets/autoload.less';