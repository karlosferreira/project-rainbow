# Shoutbox

## App Info

- `App name`: Shoutbox
- `Version`: 4.3.4
- `Link on Store`: https://store.phpfox.com/product/1654/shoutbox
- `Demo site`: https://v4.phpfox.com
- `Owner`: phpFox

## Installation Guide

Please follow below steps to install Shoutbox app:

1. Install the Shoutbox app from the store.

2. Clear `Cache` on your site.

Congratulation! You have completed installation process.
