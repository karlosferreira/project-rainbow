<?php

$aBundleScripts[] = [
    'autoload.css' => 'app_core-twemoji-awesome',
    'autoload.js' => 'app_core-twemoji-awesome',
];