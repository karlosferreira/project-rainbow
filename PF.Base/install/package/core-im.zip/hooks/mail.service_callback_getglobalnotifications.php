<?php
if (setting('pf_im_node_server')) {
    $iTotal = 0;
}