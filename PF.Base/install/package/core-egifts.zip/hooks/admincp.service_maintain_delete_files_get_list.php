<?php
$aPluginFiles[] = 'PF.Base/module/egift/';