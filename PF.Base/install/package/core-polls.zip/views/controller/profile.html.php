<?php
/**
 *
 *
 * @copyright		[PHPFOX_COPYRIGHT]
 * @author  		phpFox LLC
 * @package  		Poll
 *
 */
 
defined('PHPFOX') or exit('NO DICE!'); 

?>
{template file='poll.controller.index'}