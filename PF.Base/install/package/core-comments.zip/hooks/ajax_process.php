<?php

Phpfox::getService('comment')->setCommentLimitSettings();
