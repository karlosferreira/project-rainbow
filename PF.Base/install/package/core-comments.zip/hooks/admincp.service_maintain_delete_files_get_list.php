<?php
$aPluginFiles[] = 'PF.Base/module/comment/';