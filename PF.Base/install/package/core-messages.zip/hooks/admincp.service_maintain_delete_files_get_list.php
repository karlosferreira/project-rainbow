<?php
$aPluginFiles[] = 'PF.Base/module/mail/';
$aPluginFiles[] = 'PF.Base/less/modules/mail.less';