<?php

$aBundleScripts[] = [
    'autoload.js' => 'app_core-messages',
    'autoload.css' => 'app_core-messages',
];