# phpFox Storage

## App Info

- `App name`: Storage CDN
- `Version`: 4.6.4
- `Link on Store`: https://store.phpfox.com/product/1859/cdn
- `Demo site`: https://v4.phpfox.com
- `Owner`: phpFox

## Installation Guide

Please follow below steps to install the app:

1. Give 777 permission for folder **PF.Site/Apps/core-cdn/**.

2. Install the **phpFox Storage** app from the store.

3. Clear cache on your site.

Congratulation! You have completed the installation process.