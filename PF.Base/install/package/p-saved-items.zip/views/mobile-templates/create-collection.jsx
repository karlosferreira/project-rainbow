<div style={{ width: "100%", height: 180, alignItems: 'center', justifyContent: 'center', flex: 1, flexDirection: "column", backgroundColor: "primary_lightest", paddingLeft: 16, paddingRight: 16}} onPress={() => $.customAction('saveditems-collection/create_collection')}>
  <icon name="folder-plus-o" size={36} color="primary"></icon>
  <p style={{ marginTop: 4, color: "primary", fontSize: "large", fontWeight: "bold" }}>{$.translate('saveditems_create_new_collection_uc_first')}</p>
</div>