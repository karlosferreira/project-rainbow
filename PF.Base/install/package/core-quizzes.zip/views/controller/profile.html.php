<?php
/**
 *
 * @copyright		[PHPFOX_COPYRIGHT]
 * @author  		phpFox LLC
 * @package  		Quiz
 * @version 		4.5.3
 *
 */
 
defined('PHPFOX') or exit('NO DICE!'); 

?>
{template file='quiz.controller.index'}