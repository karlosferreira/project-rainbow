# Better Ads

## App Info

- `App name`: Better Ads
- `Version`: 4.2.9
- `Store link`: https://store.phpfox.com/product/1665/better-ads
- `Demo site`: https://v4.phpfox.com
- `Owner`: phpFox

## Installation Guide

Please follow below steps to install Better Ads app:

1. Install the Better Ads app from the store.

2. Clear cache on your site.

Congratulation! You have completed the installation process.
