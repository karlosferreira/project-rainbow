<?php

$aBundleScripts[] = [
    'autoload.css' => 'app_core-better-ads',
    'autoload.js' => 'app_core-better-ads',
];
