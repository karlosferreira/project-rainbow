<?php

$aBundleScripts[] = [
    'autoload.js' => 'app_p-status-background'
];