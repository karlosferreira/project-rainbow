<?php

if (Phpfox::isAppActive('P_StatusBg')) {
    $data['general']['pstatusbg'] = true;
}
