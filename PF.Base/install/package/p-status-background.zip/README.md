# Status Background

## App Info

- `App name`: Status Background
- `Version`: 4.1.2
- `Link on Store`: https://store.phpfox.com/product
- `Demo site`: https://v4.phpfox.com
- `Owner`: phpFox

## Installation Guide

Please follow below steps to install new phpFox Status Background app:

1. Install the Status Background app from the store.

2. Clear `Cache` and `Rebuild Core Theme` on your site.

Congratulation! You have completed installation process.