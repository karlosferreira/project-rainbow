# CDN Service

## App Info

- `App name`: CDN Service
- `Version`: 4.6.0
- `Link on Store`: https://store.phpfox.com/product/1880/cdn-service
- `Demo site`: https://v4.phpfox.com
- `Owner`: phpFox

## Installation Guide

Please follow below steps to install CDN Service app:

1. Give 777 permission for folder **PF.Site/Apps/core-cdn-service/**.

2. Install the CDN Service app from the store.

3. Clear cache on your site

Congratulation! You have completed installation process.