<?php 
defined('PHPFOX') or exit('NO DICE!');
?>
<div class="pages-category collapse-fixed">
    {template file='core.block.category'}
</div>