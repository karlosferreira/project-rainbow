# Reaction :: Change Log

## Version 4.1.1

### Information

- **Release Date:** 
- **Best Compatibility:** phpFox >= 4.7.5

## Version 4.1.0

### Information

- **Release Date:** May 03, 2019
- **Best Compatibility:** phpFox >= 4.7.5