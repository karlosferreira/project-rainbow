# Reaction

## App Info

- `App name`: Reaction
- `Version`: 4.1.1
- `Link on Store`: https://store.phpfox.com/product
- `Demo site`: https://v4.phpfox.com
- `Owner`: phpFox

## Installation Guide

Please follow below steps to install new phpFox Reaction app:

1. Install the Reaction app from the store.

2. Clear `Cache` and `Rebuild Core Theme` on your site.

Congratulation! You have completed installation process.