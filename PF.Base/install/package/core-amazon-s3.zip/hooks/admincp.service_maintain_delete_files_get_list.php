<?php
$aPluginFiles[] = 'PF.Site/Apps/core-amazon-s3/assets';
$aPluginFiles[] = 'PF.Site/Apps/core-amazon-s3/vendor';
$aPluginFiles[] = 'PF.Site/Apps/core-amazon-s3/composer.json';
$aPluginFiles[] = 'PF.Site/Apps/core-amazon-s3/composer.lock';


