<?php
/**
 * [PHPFOX_HEADER]
 *
 * @copyright		[PHPFOX_COPYRIGHT]
 * @author  		phpFox LLC
 * @package 		Phpfox
 * @version 		$Id: complete.html.php 671 2009-06-12 17:12:28Z phpFox LLC $
 */

defined('PHPFOX') or exit('NO DICE!');

?>