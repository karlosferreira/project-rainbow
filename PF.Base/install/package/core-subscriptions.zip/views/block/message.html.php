<?php
/**
 * [PHPFOX_HEADER]
 *
 * @copyright		[PHPFOX_COPYRIGHT]
 * @author  		phpFox LLC
 * @package  		Module_Subscribe
 * @version 		$Id: message.html.php 225 2009-02-13 13:24:59Z phpFox LLC $
 */

defined('PHPFOX') or exit('NO DICE!');

?>
{_p var='your_membership_group_does_not_have_rights'}