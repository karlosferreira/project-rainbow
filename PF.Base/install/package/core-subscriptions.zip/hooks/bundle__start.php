<?php

$aBundleScripts[] = [
    'autoload.js' => 'app_core-subscriptions',
    'autoload.css' => 'app_core-subscriptions',
];