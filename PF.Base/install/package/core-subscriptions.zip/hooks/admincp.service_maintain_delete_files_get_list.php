<?php
$aPluginFiles[] = 'PF.Base/module/subscribe/';
$aPluginFiles[] = 'PF.Base/less/modules/subscribe.less';