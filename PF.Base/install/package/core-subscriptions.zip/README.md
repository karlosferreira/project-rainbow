# Subscriptions

## App Info

- `App name`: Subscriptions
- `Version`: 4.6.7
- `Store link`: https://store.phpfox.com/product/
- `Demo site`: https://v4.phpfox.com
- `Owner`: phpFox

## Installation Guide

Please follow below steps to install Subscriptions app:

1. Install the Subscriptions app from the store.

2. Remove files no longer used (at Admin Panel > Maintenance > Remove files no longer used).

3. Clear `Cache` and `Rebuild Core Theme` on your site.

Congratulation! You have completed the installation process.
