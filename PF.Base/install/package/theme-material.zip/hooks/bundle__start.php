<?php

$aBundleScripts[] = [
    'autoload.js'  => 'flavor',
    'autoload.css' => 'flavor',
];

$aBundleScripts[] = [
    'autoload.js' => 'flavors_bootstrap',
];
