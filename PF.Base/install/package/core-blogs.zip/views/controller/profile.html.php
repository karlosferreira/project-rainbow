<?php 
defined('PHPFOX') or exit('NO DICE!');
?>
{template file='blog.controller.index'}
