# CKEditor

## App Info

- `App name`: CKEditor
- `Version`: 4.2.5
- `Store link`: https://store.phpfox.com/product/1655/ckeditor
- `Demo site`: https://v4.phpfox.com
- `Owner`: phpFox

## Installation Guide

Please follow below steps to install CKEditor app:

1. Install the CKEditor app from the store.

2. Clear cache on your site

Congratulation! You have completed installation process.