<?php


namespace Apps\Core_MobileApi\Api\Form\Photo;

use Apps\Core_MobileApi\Api\Form\SearchForm;


class PhotoSearchForm extends SearchForm
{

}