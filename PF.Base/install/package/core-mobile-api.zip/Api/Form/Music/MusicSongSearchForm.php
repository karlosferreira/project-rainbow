<?php


namespace Apps\Core_MobileApi\Api\Form\Music;

use Apps\Core_MobileApi\Api\Form\SearchForm;


class MusicSongSearchForm extends SearchForm
{

}