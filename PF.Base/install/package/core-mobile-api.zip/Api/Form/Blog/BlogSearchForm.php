<?php


namespace Apps\Core_MobileApi\Api\Form\Blog;

use Apps\Core_MobileApi\Api\Form\SearchForm;

class BlogSearchForm extends SearchForm
{

}
