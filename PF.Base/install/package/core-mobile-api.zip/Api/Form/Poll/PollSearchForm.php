<?php


namespace Apps\Core_MobileApi\Api\Form\Poll;

use Apps\Core_MobileApi\Api\Form\SearchForm;


class PollSearchForm extends SearchForm
{

}