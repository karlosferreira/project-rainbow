<?php


namespace Apps\Core_MobileApi\Api\Form\Video;

use Apps\Core_MobileApi\Api\Form\SearchForm;


class VideoSearchForm extends SearchForm
{

}