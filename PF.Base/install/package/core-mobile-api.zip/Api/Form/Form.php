<?php
/**
 * Created by PhpStorm.
 * User: pro
 * Date: 14/6/18
 * Time: 10:32 AM
 */

namespace Apps\Core_MobileApi\Api\Form;


class Form extends GeneralForm
{
    /**
     * @return mixed|void
     */
    function buildForm()
    {
        // Do nothing
    }
}