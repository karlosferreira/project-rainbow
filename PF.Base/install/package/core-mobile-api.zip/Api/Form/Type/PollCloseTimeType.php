<?php

namespace Apps\Core_MobileApi\Api\Form\Type;

class PollCloseTimeType extends DateTimeType
{
    protected $componentName = 'PollCloseTime';
}