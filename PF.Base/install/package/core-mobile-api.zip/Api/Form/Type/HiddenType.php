<?php
/**
 * Created by PhpStorm.
 * User: pro
 * Date: 25/5/18
 * Time: 3:45 PM
 */

namespace Apps\Core_MobileApi\Api\Form\Type;


class HiddenType extends GeneralType
{
    protected $componentName = 'Hidden';

}