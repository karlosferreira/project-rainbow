<?php


namespace Apps\Core_MobileApi\Api\Resource\FeedEmbed;


class StatusComment extends FeedEmbed
{

    public function toArray()
    {
        return null;
    }
}