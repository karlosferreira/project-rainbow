<?php
/**
 * Created by PhpStorm.
 * User: pro
 * Date: 9/8/18
 * Time: 3:26 PM
 */

namespace Apps\Core_MobileApi\Api\Resource\FeedEmbed;


class CustomRelation extends FeedEmbed
{

    public function toArray()
    {
        return null;
    }
}