<?php

namespace Apps\Core_MobileApi\Api\Resource\FeedEmbed;


class Custom extends FeedEmbed
{

    function toArray()
    {
        return null;
    }
}