# Mobile Api

## App Info

- `App name`: Mobile Api
- `Version`: 4.6.8
- `Link on Store`: https://store.phpfox.com/product/
- `Owner`: phpFox

## Installation Guide

Require `RESTful API 4.2.0` app

Please follow below steps to install Mobile Api app:

1. Install the Mobile Api app from the store.

2. Clear cache on your site

Congratulation! You have completed installation process.