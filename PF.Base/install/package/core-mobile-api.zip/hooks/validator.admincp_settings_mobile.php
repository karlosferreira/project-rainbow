<?php

$aValidation = [
    'mobile_limit_menu_show_first' => [
        'def'   => 'int',
        'min'   => '0',
        'title' => _p('how_many_menus_show_first_must_be_greater_or_equal_to_0'),
    ],
];
